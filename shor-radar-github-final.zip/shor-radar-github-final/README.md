# SHOʻR RADAR

**SHOʻR RADAR** — Oʻzbekiston hududidagi tuproq shoʻrlanishini kuzatishga moʻljallangan prototip. Loyiha FastAPI backend va `main.py` ichiga joylangan HTML/CSS/JavaScript interfeysidan foydalanadi.

## Hozirgi imkoniyatlar

- Foydalanuvchi profilini yaratish (brauzer `localStorage` xotirasida)
- Namunaviy maydonlar xaritasi va roʻyxati
- Copernicus Data Space orqali Sentinel-2 L2A maʼlumotlarini soʻrash
- Tuproq suratidan tuz poʻstlogʻi ulushini ranglar asosida taxminlash
- Shoʻr yuvish uchun suv hajmini hisoblash
- Qoidalarga asoslangan agronom yordamchisi
- Oʻlchovlarni brauzer tarixida saqlash

> Ayrim maydonlar va ko‘rsatkichlar hozircha DEMO maʼlumotlaridir. Interfeysdagi demo raqamlarni haqiqiy dala oʻlchovi deb qabul qilmang.

## Talablar

- Python 3.10 yoki undan yangi versiya
- Copernicus Data Space hisobidan olingan OAuth `client ID` va `client secret` (Sentinel-2 API funksiyasi uchun)

## Kompyuterda ishga tushirish

### 1. Loyihani yuklab oling

GitHub repository'ni ZIP shaklida yuklab oling yoki clone qiling.

### 2. Virtual muhit yarating

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.venv\\Scripts\\Activate.ps1
```

macOS / Linux:

```bash
source .venv/bin/activate
```

### 3. Kutubxonalarni oʻrnating

```bash
pip install -r requirements.txt
```

### 4. Maxfiy kalitlarni sozlang

`.env.example` faylidan nusxa olib, nomini `.env` qiling. Soʻng Copernicus kalitlarini kiriting:

```env
CDSE_CLIENT_ID=your_client_id
CDSE_CLIENT_SECRET=your_client_secret
```

**Muhim:** hozirgi `main.py` `.env` faylini avtomatik oʻqimaydi. Kalitlarni hosting platformasining Environment Variables bo‘limiga kiriting yoki terminalda muhit oʻzgaruvchisi sifatida belgilang.

Windows PowerShell:

```powershell
$env:CDSE_CLIENT_ID="your_client_id"
$env:CDSE_CLIENT_SECRET="your_client_secret"
```

macOS / Linux:

```bash
export CDSE_CLIENT_ID="your_client_id"
export CDSE_CLIENT_SECRET="your_client_secret"
```

`.env` faylini GitHub'ga yuklamang.

### 5. Serverni ishga tushiring

```bash
uvicorn main:app --reload
```

Brauzerda quyidagini oching:

- Ilova: http://127.0.0.1:8000
- Server holati: http://127.0.0.1:8000/health

## API yoʻllari

| Yoʻl | Vazifasi |
|---|---|
| `GET /` | Web ilovani ochadi |
| `GET /health` | Server holatini qaytaradi |
| `GET /salinity?lat=40.55&lon=68.65&days=60` | Sentinel-2 asosida taxminiy tahlil soʻraydi |

## GitHub'ga yuklash

1. GitHub'da yangi repository yarating.
2. Ushbu papkadagi fayllarni repository'ning asosiy (root) qismiga yuklang.
3. `CDSE_CLIENT_ID` va `CDSE_CLIENT_SECRET` qiymatlarini GitHub kodiga yozmang.
4. `.env` faylini repository'ga qoʻshmang.

## Ilmiy va texnik cheklovlar

- Sentinel-2 shoʻrlanishni bevosita laboratoriya usulida oʻlchamaydi. `level()` ichidagi SI/NDVI chegaralari taxminiy evristik qoidalardir.
- `ec_estimate` haqiqiy EC-metr natijasi emas; u taxminiy ko‘rsatkich. Muhim agronomik qarorlardan oldin tuproq namunasi va EC-metr/laboratoriya tahlili bilan tasdiqlash zarur.
- Surat tahlili rangga asoslangan soddalashtirilgan taxmindir. Tuproq turi, namlik, yorugʻlik va kamera natijaga taʼsir qiladi.
- Agronom chat tashqi AI xizmatiga ulanmagan; oldindan yozilgan qoidalardan foydalanadi.
- Profil va tahlil tarixi faqat joriy brauzer qurilmasida saqlanadi.
- Hozircha haqiqiy dalalar bazasi, foydalanuvchi autentifikatsiyasi va server tomonidagi doimiy tarix ombori mavjud emas.

## Litsenziya

Loyiha uchun ochiq manba litsenziyasi hozircha belgilanmagan.
